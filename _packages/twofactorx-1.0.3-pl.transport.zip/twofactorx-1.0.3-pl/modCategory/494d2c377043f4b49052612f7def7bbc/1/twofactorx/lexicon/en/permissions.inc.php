<?php
/**
 * Permissions Lexicon Entries for TwoFactorX
 *
 * @package twofactorx
 * @subpackage lexicon
 */
$_lang['twofactorx.permission.twofactorx_edit_desc'] = 'To update the TwoFactorX data in the user edit page.';
