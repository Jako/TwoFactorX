<?php
/**
 * Permissions Lexicon Entries for TwoFactorX
 *
 * @package twofactorx
 * @subpackage lexicon
 */
$_lang['twofactorx.permission.twofactorx_edit_desc'] = 'Zum Aktualisieren der TwoFactorX-Daten auf der Benutzer-Bearbeiten-Seite.';
