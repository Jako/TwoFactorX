<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS
',
    'readme' => '# TwoFactorX

Add a two-factor TOTP authentication to the MODX manager.

- Author: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2
- Based on the ideas and some code of GoogleAuthenticatorX by Mina Gerges <mina@minagerges.com>

## Features

With this package for MODX Revolution the manager login can be secured with a
two-factor authentication. The "Login" extra can be secured with a pre-hook and
a QR Code for saving the authenticator secret can be generated with a snippet.

## Fork

This package is a fork and a complete rewrite of GoogleAuthenticatorX package.
The reasons can be found on the [contributors]
(https://jako.github.io/TwoFactorX/contributors/) page.

## Installation

MODX Package Management

## Usage

Install via package manager. When the system setting enable_2fa is enabled, a
manager user has to verify the TOTP secret. Otherwise, the authenticator secret
verify window is displayed with each manager load. When it is verified, the
manager user has to use the TOTP key to log in to the manager. The TOTP
authentication can be disabled on manager user base.

## Documentation

For more information please read the documentation on
https://jako.github.io/TwoFactorX/

## GitHub Repository

https://github.com/Jako/TwoFactorX

## Translations

Translations of TwoFactorX can be made on
[Weblate](https://hosted.weblate.org/projects/modx-extras/twofactorx/)

## Third party licenses

This extra includes third party software, for which we are thankful.

* bacon/bacon-qr-code@2.0.8 [BSD-2-Clause]
* dasprid/enum@1.0.6 [BSD-2-Clause]
* endroid/qr-code@4.6.1 [MIT]
* phpgangsta/googleauthenticator@dev-master 505c2af [BSD-4-Clause]',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.5] - 2026-11-14

### Security

- Check the code in the TwoFactorXLogin hook for all users with enabled two-factor authentication.
- Limit the code attempts and accept each code only once.
- Don\'t reset all secrets, if the encryption key is invalid.
- Remove the secret from the QR code URL and the server paths from the manager.

### Fixed

- Fix fatal errors, the GoogleAuthenticatorX migration and the email languages.
- Hide the TwoFactorX tab on the create user page.

## [1.1.4] - 2026-10-05

### Security

- Fix complete bypass of the second authentication factor

The security issue was detected by Sosecure; Grim The Ripper Team by SOSECURE Thailand; Mr. Warathap Ratsameekomon

## [1.1.3] - 2026-07-01

### Fixed

- Fix PHP warning: Undefined array key "totp_disabled"

## [1.1.2] - 2025-12-15

### Fixed

- Fix PHP warning: Undefined array key "verifytotp"

## [1.1.1] - 2025-07-09

### Fixed

- Fix toggling the TOTP activation status in the TwoFactorX tab

## [1.1.0] - 2025-07-08

### Changed

- Remove the `twofactorx.enable_onetime` system setting and allow the user to reload the manager showing a verify window with each load.
- Verify the secret in the authenticator app with the generated authentication key to enable the two-factor authentication in the manager login.
- Migrate the `inonetime` user setting to the `verifytotp` user setting

### Fixed

- Get the right email language in MODX 3

## [1.0.8] - 2025-03-02

### Changed

- Mail the QR code image as PNG to avoid Webmailer issues (i.e. Gmail strips SVGs for security reasons)

## [1.0.7] - 2025-02-16

### Fixed

- Fix the QR code image in the email to the user [#8] – thanks to Hylke (https://github.com/hylkest)

## [1.0.6] - 2024-09-05

### Changed

- Update internal composer.phar to 2.7.9

## [1.0.5] - 2024-04-24

### Added

- Check the code in the TwoFactorXLogin hook only, when the user has to use the two-factor authentication.
- Show the QR code only with the UserQRcode snippet, when the user can use the two-factor authentication.

### Fixed

- Fix the return value of the TwoFactorXLogin hook.

## [1.0.4] - 2024-02-14

### Fixed

- Fix undefined array key warning

## [1.0.3] - 2024-02-10

### Changed

- Password managers can automatically fill the otp-field

## [1.0.2] - 2024-01-11

### Fixed

- Fix a wrong encoded URL in the QR code

## [1.0.1] - 2023-12-28

### Added

- Migrate GoogleAuthenticatorX settings and extended user fields

### Changed

- Some UI improvements
- German lexicon improvements

## [1.0.0] - 2023-12-25

### Added

- Initial Release as a complete rewrite of GoogleAuthenticatorX

### Changed

- Use internal QR code generation
- Name change because it is not limited to one two-factor authentication application
- MODX 3 compatibility
- Code simplification
- Common code structure for better use of the MODX API
- Rename some system settings
- Use MODX permissions in the user edit page and in the processors
- Use Composer for the third party software
',
    'setup-options' => 'twofactorx-1.1.5-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f5284881a21e857121b59ee7ab759953',
      'native_key' => 'twofactorx',
      'filename' => 'modNamespace/828b14afd2e1c39ea8195ba3e37e3925.vehicle',
      'namespace' => 'twofactorx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8a9fec30fee4384c2c8bc1d6782f09a',
      'native_key' => 'twofactorx.debug',
      'filename' => 'modSystemSetting/182e82cde5c021eb077b3da35629fcc7.vehicle',
      'namespace' => 'twofactorx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbd92ae98cfff415d1718d85193435d2',
      'native_key' => 'twofactorx.enable_2fa',
      'filename' => 'modSystemSetting/47e0966a0c66b5d70dbaec3795e29845.vehicle',
      'namespace' => 'twofactorx',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4183f0130abb721c032dc702ef592e2',
      'native_key' => 'twofactorx.show_in_profile',
      'filename' => 'modSystemSetting/4f400636be8fedaff9e7f2b6083b49d0.vehicle',
      'namespace' => 'twofactorx',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9568345c74d9a7ddc2b5d7f159fd18d',
      'native_key' => 'twofactorx.issuer',
      'filename' => 'modSystemSetting/fb89daa953a57a986f028a5dd0a54918.vehicle',
      'namespace' => 'twofactorx',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f163e495852e2f9adcdc05a3a8504048',
      'native_key' => 'twofactorx.encryption_key',
      'filename' => 'modSystemSetting/04aae2e41958df4dcea60aa7f1f44290.vehicle',
      'namespace' => 'twofactorx',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0a5e519ce6eafed2728ebf472b4a1c2a',
      'native_key' => NULL,
      'filename' => 'modCategory/02098e3f7a7044fa4eb19627b38bd773.vehicle',
      'namespace' => 'twofactorx',
    ),
  ),
);