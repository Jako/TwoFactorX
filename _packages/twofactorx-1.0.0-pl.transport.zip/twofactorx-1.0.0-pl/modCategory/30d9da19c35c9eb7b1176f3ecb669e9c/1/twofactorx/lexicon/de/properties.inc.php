<?php
/**
 * Properties Lexicon Entries for TwoFactorX
 *
 * @package twofactorx
 * @subpackage lexicon
 */
$_lang['twofactorx.twofactorxlogin.twofactorxErrorMsg'] = 'Alternative Fehlermeldung, wenn der Authentifizierungscode nicht übereinstimmt.';
$_lang['twofactorx.userqrcode.placeholderPrefix'] = 'Das Präfix für die vom Snippet gesetzten Platzhalter.';
$_lang['twofactorx.userqrcode.userid'] = 'Die ID des Benutzers, für den der QR-Code erstellt wird.';
