<?php
/**
 * Properties Lexicon Entries for TwoFactorX
 *
 * @package twofactorx
 * @subpackage lexicon
 */
$_lang['twofactorx.twofactorxlogin.twofactorxErrorMsg'] = 'Alternative error message, if the authentication code does not match.';
$_lang['twofactorx.userqrcode.placeholderPrefix'] = 'The prefix for the placeholders set by the snippet.';
$_lang['twofactorx.userqrcode.userid'] = 'The id of the user the QR code is created for.';
